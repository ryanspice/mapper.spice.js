/* @flow */

import React from 'react';
import ReactWinJS from 'react-winjs';

export default class AppBar extends ReactWinJS.AppBar {

	constructor(props:Object){

		super(props);

	}

	render(){

			return (
				<div>





				</div>
			);

	}

}
