
export type App = {
    OnLoad(self: object):void;
};
