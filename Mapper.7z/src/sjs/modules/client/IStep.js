export type IStep = {


    delta_speed:Number,
    increment:Number,
    addings:Number,
    adding:Number,
    delta:Number,

    frames:Number,
    fps:Number

}
